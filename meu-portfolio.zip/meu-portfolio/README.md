# Meu Portfólio

Portfólio de **Rafael Souza França**, aluno do 1º ano de Desenvolvimento de Sistemas na Etec.

Feito com HTML, CSS e JavaScript (site estático, sem build).

## Estrutura

```
meu-portfolio/
  index.html
  style.css
  script.js
  imagens/
    logo.svg
```
